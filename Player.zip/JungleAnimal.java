class FarmAnimal {
    private String name;
    private String sound;

    public FarmAnimal(String name, String sound){
        this.name=name;
        this.sound=sound;
    }

    public void makeNoise(){
        String output=name+"goes: "+sound;
        System.out.println(output);
    }
}

/**
 * JungleAnimal
 */
class JungleAnimal extends FarmAnimal{
    private String predator;
    public JungleAnimal(String name, String sound, String predator){
        super(name,sound);
        this.predator=predator;
    }
    @Override
    public void makeNoise(){
        System.out.println("I'm from jungle, I'm scared of "+predator);
    }
    
}