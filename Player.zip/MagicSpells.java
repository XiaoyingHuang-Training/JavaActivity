/**
 * MagicSpells
 */
interface MagicSpells {
    void castSpell();
} 

class UnlockingCharm implements MagicSpells{
    public void castSpell(){
        System.out.println("Alohomora");
    }
}

class ExtensionCharm implements MagicSpells{
    public void castSpell(){
        System.out.println("Capacious extremis");
    }
}

class EngorgementCharm implements MagicSpells{
    public void castSpell(){
        System.out.println("Engorgio");
    }
}