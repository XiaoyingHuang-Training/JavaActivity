
//Instantiate multiple objects using each constructor

public class Main{
    public static void main (String[] args){
        MyClass obj1=new MyClass("Alice");
        MyClass obj2=new MyClass("Bob", 25);
        MyClass obj3=new MyClass("Candy", 20,"candy.can@gmail.com");

        System.out.println(obj1);
        System.out.println(obj2);
        System.out.println(obj3);
        System.out.println("Instance count: "+MyClass.getInstanceCount());
    }
}