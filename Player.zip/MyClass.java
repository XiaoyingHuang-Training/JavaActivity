public class MyClass {
    private static int instanceCount=0;
    private String name;
    private int age;
    private String email;

    //Constructor 1
    public MyClass(String name){
        this(name,0);
    }

    //Constructor 2
    public MyClass(String name, int age){
        this.name=name;
        this.age=age;
        instanceCount++;
    }

    //Constructor 2
    public MyClass(String name, int age, String email){
        this.name=name;
        this.age=age;
        this.email=email;
        instanceCount++;
    }

    //Override the toString method
    @Override
    public String toString(){
        return "MyClass(name='"+name+"', age="+age+", email="+email+")";
    }

    //Static method to get the instance count
    public static int getInstanceCount(){
        return instanceCount;
    }
}
