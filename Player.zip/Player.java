public class Player {
    private String name;
    private int health;
    private String signature;

    public String getName(){
        return name;
    }

    public void setName(String newName){
        this.name=newName;
    }

    public int getHealth(){
        return health;
    }

    public void setHealth(int newHealth){
        this.health=newHealth;
    }

    public String getSignature(){
        return signature;
    }

    public void setSignature(String newSignature){
        this.signature=newSignature;
    }
    //Test
    public static void main(String[] args){
        Player player=new Player();
        player.setName("Karen");
        player.setHealth(500);
        player.setSignature("I don't care.");
        String playerName=player.getName();
        int playerHealth=player.getHealth();
        String playerSignature=player.getSignature();
        System.out.println("Hello, I am "+playerName+". My health is "+playerHealth+". My signature is:\" "+playerSignature+'"');
    }

}

