public class TestCharacters {
    public static void main(String[] args){
        Character[] harryPotterCharacters=new Character[2];
        harryPotterCharacters[0]=new goodWizzardWitch();
        harryPotterCharacters[1]=new badWizzardWitch();

        for (Character character:harryPotterCharacters){
            character.doSpell();
            character.saySomething();
        }
    }
}
