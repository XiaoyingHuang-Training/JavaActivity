public class TestInterface {
    public static void main (String[] args){
        MagicSpells[] magicSpells=new MagicSpells[3];
        magicSpells[0]=new UnlockingCharm();
        magicSpells[1]=new ExtensionCharm();
        magicSpells[2]=new EngorgementCharm();

        for (MagicSpells spell: magicSpells){
            spell.castSpell();
        }
    }
}
