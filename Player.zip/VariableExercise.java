import java.util.Scanner;

public class VariableExercise {
    public static void main(String[] args){
        // String firstName;
        // String lastName;

        // firstName="Karen";
        // lastName="Doesntcare";

        // String name=firstName+" "+lastName;

        // System.out.println(name);
        // int num1;
        // int num2;
        // num1=1;
        // num2=2;
        // int sum=num1+num2;
        // System.out.println(sum);

        // double result;
        // result=(double) num1/num2;
        // System.out.println(result);

        // int num3=8;
        // System.out.println(num3++);
        // System.out.println(++num3);

        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter your first name");
        String firstName=scanner.nextLine();
        System.out.println("Enter your last name");
        String lastName=scanner.nextLine();
        System.out.println("Hello, "+firstName+" "+lastName);
        System.out.println("Next, enter a whole number");
        int firstNum=scanner.nextInt();
        System.out.println("Enter another number");
        int secondNum=scanner.nextInt();
        System.out.println("The sum of the two numbers is "+(firstNum+secondNum));
    }
}